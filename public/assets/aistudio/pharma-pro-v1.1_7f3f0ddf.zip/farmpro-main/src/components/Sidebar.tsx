import React from 'react';
import {
  LayoutDashboard,
  Users,
  ShoppingCart,
  Boxes,
  Receipt,
  BarChart3,
  Settings,
  Phone,
  MessageSquare,
  Award,
  AlertTriangle,
  X,
  ShieldCheck,
  Key,
  Sparkles,
  History,
  PackagePlus,
} from 'lucide-react';
import { AppSettings, UserRole } from '../types';

export type NavTab =
  | 'dashboard'
  | 'entities'
  | 'transactions'
  | 'pos'
  | 'inventory'
  | 'purchases'
  | 'expenses'
  | 'reports'
  | 'settings'
  | 'super_admin';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  settings: AppSettings;
  onOpenAbout: () => void;
  onOpenThemeSelector?: () => void;
  onOpenDeviceSync?: () => void;
  onOpenInstanceManager?: () => void;
  currentRole?: UserRole;
  onOpenSuperAdmin?: () => void;
  onSwitchRole?: () => void;
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
  nearExpiryCount?: number;
  lowStockCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  settings,
  onOpenAbout,
  onOpenThemeSelector,
  onOpenDeviceSync,
  onOpenInstanceManager,
  currentRole = 'admin',
  onOpenSuperAdmin,
  onSwitchRole,
  isMobileOpen = false,
  onCloseMobile,
  nearExpiryCount = 0,
  lowStockCount = 0,
}) => {
  const isPharmacist = currentRole === 'pharmacist';

  const navItems = [
    {
      id: 'dashboard' as NavTab,
      label: 'لوحة التحكم',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'entities' as NavTab,
      label: 'دفتر الحسابات',
      icon: Users,
      badge: 'الرئيسي',
      badgeColor: 'bg-indigo-100 text-indigo-700',
    },
    {
      id: 'transactions' as NavTab,
      label: 'سجل الحركات',
      icon: History,
      badge: 'سجلات',
      badgeColor: 'bg-cyan-100 text-cyan-800 font-bold',
    },
    {
      id: 'pos' as NavTab,
      label: 'نقطة البيع',
      icon: ShoppingCart,
      badge: 'سريع',
      badgeColor: 'bg-emerald-100 text-emerald-700',
    },
    {
      id: 'inventory' as NavTab,
      label: 'المخزون والأدوية',
      icon: Boxes,
      badge: nearExpiryCount > 0 ? `${nearExpiryCount} صلاحية` : null,
      badgeColor: 'bg-amber-100 text-amber-700',
    },
    {
      id: 'purchases' as NavTab,
      label: 'المشتريات',
      icon: PackagePlus,
      badge: null,
      adminOnly: true,
    },
    {
      id: 'expenses' as NavTab,
      label: 'المصاريف والسندات',
      icon: Receipt,
      badge: null,
    },
    {
      id: 'reports' as NavTab,
      label: 'التقارير والأرباح',
      icon: BarChart3,
      badge: null,
      adminOnly: true,
    },
    {
      id: 'settings' as NavTab,
      label: 'الإعدادات والنسخ',
      icon: Settings,
      badge: null,
      adminOnly: true,
    },
    {
      id: 'super_admin' as NavTab,
      label: 'السوبر أدمن',
      icon: Key,
      badge: currentRole === 'super_admin' ? 'نشط' : 'م. مالك',
      badgeColor: 'bg-amber-100 text-amber-900 font-bold',
      isSuper: true,
    },
  ];

  // Filter items according to permissions
  const visibleNavItems = navItems.filter(item => {
    if (item.id === 'super_admin') {
      return currentRole === 'super_admin';
    }
    if (isPharmacist && item.adminOnly) {
      return false; // Hide Reports and Settings from regular pharmacist
    }
    return true;
  });

  const content = (
    <div className="flex flex-col h-full bg-white border-l border-slate-200 text-right select-none">
      {/* Mobile close button */}
      {isMobileOpen && (
        <div className="p-4 flex items-center justify-between border-b border-slate-100 md:hidden">
          <span className="font-bold text-slate-800 text-sm">القائمة الرئيسية</span>
          <button
            onClick={onCloseMobile}
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* Nav list */}
      <nav className="flex-1 p-3 space-y-1.5 overflow-y-auto">
        {/* Role Status Badge */}
        {isPharmacist ? (
          <div className="mb-3 p-2.5 rounded-2xl bg-blue-50 border border-blue-200/90 text-blue-950 text-xs flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-1.5 font-bold">
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
              <span>وضع: مستخدم عادي (كاشير)</span>
            </div>
            {onSwitchRole && (
              <button
                type="button"
                onClick={onSwitchRole}
                className="px-2.5 py-1 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-black text-xs shadow-xs transition shrink-0"
                title="إدخال رمز PIN للانتقال لوضع المدير"
              >
                دخول كمدير 🔑
              </button>
            )}
          </div>
        ) : (
          <div className="mb-3 p-2.5 rounded-2xl bg-amber-50 border border-amber-200/90 text-amber-950 text-xs flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-1.5 font-bold">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              <span>وضع: {currentRole === 'super_admin' ? 'سوبر أدمن' : 'مدير عام الصيدلية'}</span>
            </div>
            {onSwitchRole && (
              <button
                type="button"
                onClick={onSwitchRole}
                className="px-2.5 py-1 rounded-xl bg-slate-900 hover:bg-black text-white font-black text-xs shadow-xs transition shrink-0"
                title="العودة لوضع الصيدلي العادي"
              >
                وضع الكاشير 👤
              </button>
            )}
          </div>
        )}

        <div className="text-[11px] font-bold text-slate-400 px-3 py-1 uppercase tracking-wider">
          الوحدات البرمجية المتاحة
        </div>
        {visibleNavItems.map(item => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                onSelectTab(item.id);
                if (onCloseMobile) onCloseMobile();
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-bold transition-all ${
                isActive
                  ? item.id === 'super_admin'
                    ? 'bg-amber-600 text-white shadow-sm'
                    : 'bg-slate-900 dark:bg-emerald-600 text-white shadow-sm'
                  : item.id === 'super_admin'
                  ? 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100 font-bold'
                  : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/80 hover:text-slate-950 font-bold shadow-xs'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <Icon
                  className={`w-4 h-4 shrink-0 transition-transform ${
                    isActive
                      ? 'text-white'
                      : item.id === 'super_admin'
                      ? 'text-amber-700'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                />
                <span
                  className={`truncate text-xs sm:text-sm font-bold ${
                    isActive ? 'text-white' : 'text-slate-800 dark:text-slate-100'
                  }`}
                >
                  {item.label}
                </span>
              </div>
              {item.badge && (
                <span
                  className={`text-xs px-2 py-0.5 rounded-full font-bold shrink-0 ${
                    isActive ? 'bg-white/20 text-white' : item.badgeColor
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        {/* Quick Tools: Themes & Device Sync & Pharmacy Isolation */}
        <div className="pt-2 pb-1 space-y-1">
          <div className="text-xs font-black text-slate-600 dark:text-slate-300 px-3 py-1 uppercase tracking-wider">
            المظهر والأجهزة والمقرات
          </div>
          <div className="grid grid-cols-2 gap-1.5 px-1">
            {onOpenThemeSelector && (
              <button
                type="button"
                onClick={onOpenThemeSelector}
                className="flex items-center justify-center gap-1.5 p-2 rounded-xl bg-white hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 text-xs font-black border-2 border-slate-300 dark:border-slate-600 shadow-xs transition-all"
              >
                <span>🎨 الثيمات</span>
              </button>
            )}
            {onOpenDeviceSync && (
              <button
                type="button"
                onClick={onOpenDeviceSync}
                className="flex items-center justify-center gap-1.5 p-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-950 dark:text-indigo-200 text-xs font-black border-2 border-indigo-200/90 dark:border-indigo-800/80 shadow-xs transition-all"
              >
                <span>📱 الأجهزة</span>
              </button>
            )}
          </div>
          {onOpenInstanceManager && !isPharmacist && (
            <div className="px-1">
              <button
                type="button"
                onClick={onOpenInstanceManager}
                className="w-full flex items-center justify-center gap-2 p-2 rounded-xl bg-teal-50 hover:bg-teal-100 dark:bg-teal-950/50 dark:hover:bg-teal-900/60 text-teal-950 dark:text-teal-200 text-xs font-black border-2 border-teal-200/90 dark:border-teal-800/80 shadow-xs transition-all"
              >
                <span>🏢 تخصيص وعزل النسخ</span>
              </button>
            </div>
          )}
        </div>
      </nav>

      {/* Warnings quick box if low stock or expiry */}
      {(nearExpiryCount > 0 || lowStockCount > 0) && (
        <div className="p-3 mx-3 my-2 rounded-2xl bg-amber-50/80 border border-amber-200/80 text-amber-900 text-xs space-y-1">
          <div className="flex items-center gap-1.5 font-bold">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <span>تنبيهات المخزون الهامة</span>
          </div>
          {nearExpiryCount > 0 && (
            <div className="text-amber-700">
              • {nearExpiryCount} أصناف قاربت على الانتهاء
            </div>
          )}
          {lowStockCount > 0 && (
            <div className="text-amber-700">
              • {lowStockCount} أصناف تحت الحد الأدنى
            </div>
          )}
        </div>
      )}

      {/* Designer Signature Card */}
      <div className="p-3.5 m-3 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white shadow-lg space-y-2.5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
            <Award className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs text-cyan-300 font-bold">برمجة وتطوير</div>
            <div className="text-xs font-black">{settings.designerName}</div>
          </div>
        </div>

        <div className="text-[11px] text-slate-300 flex items-center justify-between pt-1 border-t border-slate-700/60">
          <span className="font-mono dir-ltr font-bold text-cyan-200">{settings.designerPhone}</span>
          <div className="flex items-center gap-1.5">
            <a
              href={`tel:${settings.designerPhone}`}
              className="p-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
              title="اتصال بالمهندس"
            >
              <Phone className="w-3.5 h-3.5" />
            </a>
            <a
              href={`https://wa.me/970${settings.designerPhone.replace(/^0/, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1 rounded-lg bg-teal-600 hover:bg-teal-500 text-white transition-colors"
              title="واتساب المهندس"
            >
              <MessageSquare className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        <button
          onClick={onOpenAbout}
          className="w-full py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-[11px] font-bold text-cyan-100 transition-all text-center"
        >
          تفاصيل النظام والشهادة
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop static sidebar */}
      <aside className="hidden md:block w-64 lg:w-72 shrink-0 h-[calc(100vh-57px)] sticky top-[57px]">
        {content}
      </aside>

      {/* Mobile Drawer */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="fixed inset-y-0 right-0 w-72 bg-white shadow-2xl z-50 animate-in slide-in-from-right duration-200">
            {content}
          </div>
        </div>
      )}
    </>
  );
};
