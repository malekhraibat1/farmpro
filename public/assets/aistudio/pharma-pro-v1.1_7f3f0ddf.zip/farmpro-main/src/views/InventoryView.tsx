import React, { useState, lazy, Suspense } from 'react';
import {
  Boxes,
  Plus,
  Search,
  AlertTriangle,
  Clock,
  Edit,
  Trash2,
  Barcode,
  Layers,
  Sparkles,
  ArrowUpDown,
  Filter,
  FileSpreadsheet,
  Download,
  History,
  ClipboardCheck,
  Undo2,
  ShoppingBasket,
} from 'lucide-react';
import { Medicine, AppSettings, UserRole, StockMovement, Entity, SaleInvoice } from '../types';
const ExcelImportModal = lazy(() => import('../components/ExcelImportModal').then(m => ({ default: m.ExcelImportModal })));
import { ValidationService } from '../services/validationService';
import { MovementsModal, StocktakeModal, SupplierReturnModal, ReorderModal } from '../components/StockToolsModals';
import { inventoryValue, matchesQuery, normalizeMedicine, supportsRetail } from '../services/inventoryService';
import { uid } from '../services/saleService';

interface InventoryViewProps {
  medicines: Medicine[];
  settings: AppSettings;
  currentRole: UserRole;
  onAddMedicine: (med: Omit<Medicine, 'id'>) => void;
  onUpdateMedicine: (med: Medicine) => void;
  onDeleteMedicine: (id: string) => void;
  onBulkImportMedicines?: (newMeds: Medicine[], updatedMeds: Medicine[]) => void;
  movements: StockMovement[];
  entities: Entity[];
  sales: SaleInvoice[];
  onRemoveStock: (
    items: { medicineId: string; batchId: string; packs: number }[],
    kind: 'supplier_return' | 'write_off',
    opts: { entityId?: string; note?: string }
  ) => { ok: boolean; error?: string; value: number };
  onStocktake: (counts: { medicineId: string; batchId: string; counted: number }[]) => number;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  medicines,
  settings,
  currentRole,
  onAddMedicine,
  onUpdateMedicine,
  onDeleteMedicine,
  onBulkImportMedicines,
  movements,
  entities,
  sales,
  onRemoveStock,
  onStocktake,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'near_expiry' | 'expired' | 'low_stock'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showExcelModal, setShowExcelModal] = useState(false);
  const [editingMed, setEditingMed] = useState<Medicine | null>(null);
  const [importNotification, setImportNotification] = useState<{ newCount: number; updatedCount: number } | null>(null);
  const [validationError, setValidationError] = useState('');

  // Form states
  const [barcode, setBarcode] = useState('');
  const [tradeName, setTradeName] = useState('');
  const [genericName, setGenericName] = useState('');
  const [category, setCategory] = useState('أدوية عامة');
  const [unit, setUnit] = useState('علبة');
  const [stockQuantity, setStockQuantity] = useState('20');
  const [minQuantity, setMinQuantity] = useState('5');
  const [purchasePrice, setPurchasePrice] = useState('10');
  const [sellPrice, setSellPrice] = useState('15');
  const [batchNumber, setBatchNumber] = useState(`BATCH-${Math.floor(100 + Math.random() * 900)}`);
  const [expiryDate, setExpiryDate] = useState('2028-12-31');
  const [manufacturer, setManufacturer] = useState('');
  const [dosageForm, setDosageForm] = useState('');
  const [strength, setStrength] = useState('');
  const [requiresPrescription, setRequiresPrescription] = useState(false);
  const [isControlled, setIsControlled] = useState(false);
  const [unitsPerPack, setUnitsPerPack] = useState('1');
  const [subUnitName, setSubUnitName] = useState('');
  const [subUnitPrice, setSubUnitPrice] = useState('');
  const [minSellPrice, setMinSellPrice] = useState('');
  type EditBatch = { id: string; batchNumber: string; expiryDate: string; quantity: string; purchasePrice: string };
  const [editBatches, setEditBatches] = useState<EditBatch[]>([]);
  const [movementsFor, setMovementsFor] = useState<Medicine | null>(null);
  const [showStocktake, setShowStocktake] = useState(false);
  const [showReturns, setShowReturns] = useState(false);
  const [showReorder, setShowReorder] = useState(false);
  const canEdit = currentRole !== 'pharmacist';
  const nearDays = settings.nearExpiryDays ?? 90;

  // Categories list
  const categories = Array.from(new Set(medicines.map(m => m.category))).filter(Boolean);

  // Dates for filtering
  const now = new Date();
  const ninetyDays = new Date();
  ninetyDays.setDate(now.getDate() + nearDays);

  const filteredMedicines = medicines.filter(med => {
    // Search (يتجاهل التشكيل واختلاف الهمزات)
    if (searchTerm && !matchesQuery(med, searchTerm)) return false;

    // Category
    if (selectedCategory !== 'all' && med.category !== selectedCategory) return false;

    // Filter type
    const exp = med.expiryDate ? new Date(med.expiryDate) : null;
    const isValidExp = exp && !isNaN(exp.getTime());
    if (filterType === 'expired' && (!isValidExp || exp >= now)) return false;
    if (filterType === 'near_expiry' && (!isValidExp || exp < now || exp > ninetyDays)) return false;
    if (filterType === 'low_stock' && med.stockQuantity > med.minQuantity) return false;

    return true;
  });

  const handleOpenAdd = () => {
    setEditingMed(null);
    setBarcode(`6251${Math.floor(10000000 + Math.random() * 90000000)}`);
    setTradeName('');
    setGenericName('');
    setCategory('أدوية عامة');
    setUnit('علبة');
    setStockQuantity('20');
    setMinQuantity('5');
    setPurchasePrice('10');
    setSellPrice('15');
    setBatchNumber(`BATCH-${Math.floor(100 + Math.random() * 900)}`);
    setExpiryDate('2028-12-31');
    setManufacturer('');
    setDosageForm('');
    setStrength('');
    setRequiresPrescription(false);
    setIsControlled(false);
    setUnitsPerPack('1');
    setSubUnitName('');
    setSubUnitPrice('');
    setMinSellPrice('');
    setEditBatches([]);
    setValidationError('');
    setShowAddModal(true);
  };

  const handleOpenEdit = (med: Medicine) => {
    setEditingMed(med);
    setBarcode(med.barcode);
    setTradeName(med.tradeName);
    setGenericName(med.genericName);
    setCategory(med.category);
    setUnit(med.unit);
    setStockQuantity(med.stockQuantity.toString());
    setMinQuantity(med.minQuantity.toString());
    setPurchasePrice(med.purchasePrice.toString());
    setSellPrice(med.sellPrice.toString());
    setBatchNumber(med.batchNumber);
    setExpiryDate(med.expiryDate);
    setManufacturer(med.manufacturer);
    setDosageForm(med.dosageForm || '');
    setStrength(med.strength || '');
    setRequiresPrescription(!!med.requiresPrescription);
    setIsControlled(!!med.isControlled);
    setUnitsPerPack(String(med.unitsPerPack || 1));
    setSubUnitName(med.subUnitName || '');
    setSubUnitPrice(med.subUnitPrice ? String(med.subUnitPrice) : '');
    setMinSellPrice(med.minSellPrice ? String(med.minSellPrice) : '');
    setEditBatches(
      (normalizeMedicine(med).batches || []).map(b => ({
        id: b.id,
        batchNumber: b.batchNumber,
        expiryDate: b.expiryDate,
        quantity: String(b.quantity),
        purchasePrice: String(b.purchasePrice),
      }))
    );
    setValidationError('');
    setShowAddModal(true);
  };

  const handleSaveMedicine = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError('');

    const mQty = parseInt(minQuantity) || 0;
    const sPrice = parseFloat(sellPrice) || 0;
    const upp = parseInt(unitsPerPack) || 1;
    if (upp > 1 && !subUnitName.trim()) {
      setValidationError('أدخل اسم الوحدة الصغرى (شريط/حبة...) لأن العبوة تُباع بالتجزئة.');
      return;
    }

    // الكمية والتكلفة والصلاحية: من التشغيلات في وضع التعديل، ومن الحقول المفردة عند الإضافة
    let sQty = parseInt(stockQuantity) || 0;
    let pPrice = parseFloat(purchasePrice) || 0;
    let expiry = expiryDate;
    let batchNo = batchNumber.trim();
    let batchesOut: Medicine['batches'] | undefined = undefined;

    if (editingMed) {
      if (editBatches.length === 0) {
        setValidationError('أضف تشغيلة واحدة على الأقل (ولو بكمية صفر).');
        return;
      }
      for (const b of editBatches) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(b.expiryDate)) {
          setValidationError('أدخل تاريخ انتهاء صالحاً لكل تشغيلة.');
          return;
        }
        if ((parseInt(b.quantity) || 0) < 0 || (parseFloat(b.purchasePrice) || 0) < 0) {
          setValidationError('الكمية وسعر الشراء في التشغيلات لا يمكن أن يكونا سالبين.');
          return;
        }
      }
      batchesOut = editBatches.map(b => ({
        id: b.id,
        batchNumber: b.batchNumber.trim(),
        expiryDate: b.expiryDate,
        quantity: Math.max(0, parseInt(b.quantity) || 0),
        purchasePrice: Math.max(0, parseFloat(b.purchasePrice) || 0),
      }));
      const agg = normalizeMedicine({ ...editingMed, batches: batchesOut } as Medicine);
      sQty = agg.stockQuantity;
      pPrice = agg.purchasePrice;
      expiry = agg.expiryDate;
      batchNo = agg.batchNumber;
    }

    const validation = ValidationService.validateMedicine({
      barcode: barcode.trim(),
      tradeName: tradeName.trim(),
      genericName: genericName.trim(),
      category,
      unit,
      stockQuantity: sQty,
      minQuantity: mQty,
      purchasePrice: pPrice,
      sellPrice: sPrice,
      batchNumber: batchNo,
      expiryDate: expiry,
      manufacturer: manufacturer.trim(),
      dosageForm: dosageForm.trim(),
      strength: strength.trim(),
      requiresPrescription,
      isControlled,
      unitsPerPack: upp,
      subUnitName: subUnitName.trim(),
      subUnitPrice: parseFloat(subUnitPrice) || 0,
      minSellPrice: parseFloat(minSellPrice) || 0,
    });

    if (!validation.success) {
      const issue = validation.error.issues[0];
      setValidationError(issue ? issue.message : 'يرجى مراجعة بيانات الصنف المدخلة.');
      return;
    }

    // لا نسمح بتكرار الباركود
    const dup = medicines.find(m => m.barcode === barcode.trim() && m.id !== editingMed?.id);
    if (dup) {
      setValidationError(`الباركود مستخدم لصنف آخر: ${dup.tradeName}`);
      return;
    }

    const validatedData = validation.data;

    if (editingMed) {
      onUpdateMedicine({
        ...editingMed,
        ...validatedData,
        batches: batchesOut,
      } as Medicine);
    } else {
      onAddMedicine(validatedData as Omit<Medicine, 'id'>);
    }

    setShowAddModal(false);
  };

  const handleImportSuccess = (newlyAdded: Medicine[], updatedMeds: Medicine[]) => {
    if (onBulkImportMedicines) {
      onBulkImportMedicines(newlyAdded, updatedMeds);
    } else {
      newlyAdded.forEach(m => onAddMedicine(m));
      updatedMeds.forEach(m => onUpdateMedicine(m));
    }
    setImportNotification({
      newCount: newlyAdded.length,
      updatedCount: updatedMeds.length,
    });
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2">
            <Boxes className="w-6 h-6 text-cyan-600" />
            <span>إدارة المخزون والأدوية وتواريخ الصلاحية</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            تتبع الدفعات، تواريخ انتهاء الصلاحية، أسعار الشراء والبيع، والنواقص
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {currentRole !== 'pharmacist' && (
            <button
              onClick={() => setShowExcelModal(true)}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-md shadow-emerald-600/20 active:scale-95 transition-all flex items-center gap-2"
              title="استيراد أصناف وأسعار الأدوية من ملف إكسل أو CSV دفعة واحدة (خاص بالمدير)"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>استيراد أصناف من إكسل (Excel)</span>
            </button>
          )}

          {canEdit && (
            <button
              onClick={handleOpenAdd}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-cyan-600/20 active:scale-95 transition-all flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة دواء / صنف جديد</span>
            </button>
          )}
        </div>
      </div>

      {/* أدوات المخزون */}
      <div className="flex flex-wrap items-center gap-2">
        <button onClick={() => setShowReorder(true)} className="px-3.5 py-2 rounded-xl bg-white border border-slate-300 text-slate-900 text-xs font-black hover:bg-slate-100 flex items-center gap-1.5">
          <ShoppingBasket className="w-4 h-4" /> قائمة النواقص واقتراح الطلب
        </button>
        {canEdit && (
          <>
            <button onClick={() => setShowReturns(true)} className="px-3.5 py-2 rounded-xl bg-white border border-slate-300 text-slate-900 text-xs font-black hover:bg-slate-100 flex items-center gap-1.5">
              <Undo2 className="w-4 h-4" /> مرتجعات الشركات والإتلاف
            </button>
            <button onClick={() => setShowStocktake(true)} className="px-3.5 py-2 rounded-xl bg-white border border-slate-300 text-slate-900 text-xs font-black hover:bg-slate-100 flex items-center gap-1.5">
              <ClipboardCheck className="w-4 h-4" /> جرد المخزون
            </button>
            {(() => {
              const v = inventoryValue(medicines);
              return (
                <span className="ms-auto px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800">
                  قيمة المخزون: بالتكلفة <b className="font-mono">{v.cost.toFixed(2)}</b> · بسعر البيع <b className="font-mono">{v.retail.toFixed(2)}</b> {settings.currency}
                </span>
              );
            })()}
          </>
        )}
      </div>

      {/* Success Notification Banner for Excel Import */}
      {importNotification && (
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 flex items-center justify-between gap-4 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-black">
                🎉 تم استيراد بيانات الإكسل بنجاح وحفظها في الصيدلية!
              </h4>
              <p className="text-[11px] text-emerald-700 dark:text-emerald-300 mt-0.5">
                تمت إضافة <b>{importNotification.newCount}</b> صنف جديد، وتحديث أسعار ومخزون <b>{importNotification.updatedCount}</b> صنف موجود مسبقاً.
              </p>
            </div>
          </div>
          <button
            onClick={() => setImportNotification(null)}
            className="text-xs text-emerald-700 hover:text-emerald-900 font-bold px-2 py-1 rounded-lg hover:bg-emerald-100"
          >
            إغلاق
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all border-2 ${
              filterType === 'all'
                ? 'bg-slate-950 text-white border-black shadow-sm'
                : 'bg-white text-slate-900 border-slate-300 hover:bg-slate-100 shadow-2xs'
            }`}
          >
            كافة الأصناف ({medicines.length})
          </button>
          <button
            onClick={() => setFilterType('near_expiry')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 border-2 ${
              filterType === 'near_expiry'
                ? 'bg-amber-600 text-white border-amber-800 shadow-sm'
                : 'bg-amber-50 text-amber-950 border-amber-300 hover:bg-amber-100 shadow-2xs'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>قاربت على الانتهاء (&lt; 90 يوم)</span>
          </button>
          <button
            onClick={() => setFilterType('low_stock')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 border-2 ${
              filterType === 'low_stock'
                ? 'bg-rose-600 text-white border-rose-800 shadow-sm'
                : 'bg-rose-50 text-rose-950 border-rose-300 hover:bg-rose-100 shadow-2xs'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>نواقص تحت الحد الأدنى</span>
          </button>
        </div>

        {/* Search & Category selector */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
            <input
              type="text"
              placeholder="ابحث بالاسم التجاري، العلمي، الباركود، أو الشركة المصنعة..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pr-10 pl-4 py-2 text-xs rounded-2xl border border-slate-200 bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-semibold"
            />
          </div>

          <div className="w-full sm:w-56 shrink-0">
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="w-full p-2 text-xs rounded-2xl border border-slate-200 bg-white shadow-sm font-semibold text-slate-700"
            >
              <option value="all">كافة التصنيفات الطبية</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Medicines Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-100/90 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">الباركود</th>
                <th className="py-3 px-4">الاسم التجاري والعلمي</th>
                <th className="py-3 px-4">التصنيف</th>
                <th className="py-3 px-4">الكمية المتوفرة</th>
                <th className="py-3 px-4">سعر الشراء</th>
                <th className="py-3 px-4 text-emerald-800">سعر البيع</th>
                <th className="py-3 px-4">تاريخ الانتهاء</th>
                <th className="py-3 px-4">رقم الدفعة</th>
                <th className="py-3 px-4 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredMedicines.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <Boxes className="w-12 h-12 mx-auto text-slate-300 mb-3" />
                    <p className="font-bold text-slate-700 text-sm">
                      {medicines.length === 0 ? 'لا توجد أصناف مسجلة في هذه الصيدلية بعد' : 'لا توجد أدوية مطابقة للبحث أو التصفية'}
                    </p>
                    {medicines.length === 0 && (
                      <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
                        <button
                          onClick={() => setShowExcelModal(true)}
                          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/20 active:scale-95 transition-all flex items-center gap-2"
                        >
                          <FileSpreadsheet className="w-4 h-4" />
                          <span>استيراد الأصناف والأسعار من إكسل الآن</span>
                        </button>
                        <button
                          onClick={handleOpenAdd}
                          className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md shadow-cyan-600/20 active:scale-95 transition-all flex items-center gap-2"
                        >
                          <Plus className="w-4 h-4" />
                          <span>إضافة أول صنف يدوياً</span>
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ) : (
                filteredMedicines.map(med => {
                  const expDate = new Date(med.expiryDate);
                  const isExpired = expDate < now;
                  const isNearExpiry = !isExpired && expDate <= ninetyDays;
                  const isLowStock = med.stockQuantity <= med.minQuantity;

                  return (
                    <tr key={med.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                        {med.barcode}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-black text-slate-900 text-sm">{med.tradeName}</div>
                        <div className="text-xs text-slate-600">{[med.genericName, med.strength, med.dosageForm].filter(Boolean).join(" · ")}{med.requiresPrescription ? " · بوصفة" : ""}{med.isControlled ? " · خاضع للرقابة" : ""}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-semibold text-xs">
                          {med.category}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`font-mono text-sm font-black ${
                              isLowStock ? 'text-rose-600' : 'text-slate-800'
                            }`}
                          >
                            {med.stockQuantity} {med.unit}
                          </span>
                          {isLowStock && (
                            <span className="text-xs px-1.5 py-0.2 rounded bg-rose-100 text-rose-700 font-bold">
                              ناقص
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-slate-600">
                        {currentRole === 'pharmacist' ? (
                          <span className="text-slate-400 font-sans text-[11px] bg-slate-100 px-2 py-0.5 rounded-lg border border-slate-200" title="محمي لصلاحية المدير">
                            •••• 🔒
                          </span>
                        ) : (
                          `${med.purchasePrice.toFixed(2)} ${settings.currency}`
                        )}
                      </td>
                      <td className="py-3 px-4 font-mono font-black text-emerald-700 text-sm">
                        {med.sellPrice.toFixed(2)} {settings.currency}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-1 rounded-xl font-mono text-[11px] font-bold inline-block ${
                            isExpired
                              ? 'bg-rose-100 text-rose-800'
                              : isNearExpiry
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-50 text-emerald-800'
                          }`}
                        >
                          {med.expiryDate}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-700 text-xs">
                        {med.batchNumber}
                        {(med.batches?.filter(b => b.quantity > 0).length || 0) > 1 && (
                          <div className="mt-0.5 px-1.5 py-0.5 rounded bg-indigo-50 border border-indigo-200 text-indigo-900 font-sans font-black inline-block">
                            {med.batches!.filter(b => b.quantity > 0).length} تشغيلات
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setMovementsFor(med)}
                            className="p-1.5 rounded-xl bg-slate-50 text-slate-800 hover:bg-slate-100 border border-slate-300 transition-colors"
                            title="سجل حركة الصنف"
                            aria-label={`سجل حركة ${med.tradeName}`}
                          >
                            <History className="w-4 h-4" />
                          </button>
                          {canEdit && (
                            <button
                              onClick={() => handleOpenEdit(med)}
                              className="p-1.5 rounded-xl bg-sky-50 text-sky-800 hover:bg-sky-100 border border-sky-300 transition-colors shadow-2xs"
                              title="تعديل بيانات الدواء والتشغيلات"
                              aria-label={`تعديل ${med.tradeName}`}
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                          )}
                          {currentRole !== 'pharmacist' && (
                            <button
                              onClick={() => {
                                if (confirm(`هل أنت متأكد من حذف ${med.tradeName}؟`)) {
                                  onDeleteMedicine(med.id);
                                }
                              }}
                              className="p-1.5 rounded-xl bg-rose-50 text-rose-800 hover:bg-rose-100 border border-rose-300 transition-colors shadow-2xs"
                              title="حذف الصنف (خاص بالمدير)"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
            <div className="p-5 bg-gradient-to-l from-cyan-700 to-blue-800 text-white flex justify-between items-center shrink-0">
              <div>
                <h3 className="text-lg font-black">
                  {editingMed ? 'تعديل بيانات الدواء والمخزون' : 'إضافة دواء جديد للمخزون'}
                </h3>
                <p className="text-xs text-cyan-100">
                  إدخال الباركود، الأسعار، تاريخ انتهاء الصلاحية ورقم الدفعة
                </p>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveMedicine} className="p-6 space-y-4 text-xs overflow-y-auto flex-1">
              {validationError && (
                <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{validationError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">الاسم التجاري *</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: Augmentin 1g"
                    value={tradeName}
                    onChange={e => setTradeName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">الاسم العلمي (تركيبة الدواء)</label>
                  <input
                    type="text"
                    placeholder="مثال: Amoxicillin + Clavulanic"
                    value={genericName}
                    onChange={e => setGenericName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">الباركود الدولي</label>
                  <input
                    type="text"
                    required
                    value={barcode}
                    onChange={e => setBarcode(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 font-mono text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">التصنيف الطبي</label>
                  <input
                    type="text"
                    placeholder="مضاد حيوي، مسكن..."
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">الوحدة</label>
                  <input
                    type="text"
                    placeholder="علبة، شريط، زجاجة..."
                    value={unit}
                    onChange={e => setUnit(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                {!editingMed && (
                <div>
                  <label className="block text-slate-700 font-bold mb-1">سعر الشراء</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={purchasePrice}
                    onChange={e => setPurchasePrice(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 font-mono font-bold text-slate-800"
                  />
                </div>
                )}
                <div>
                  <label className="block text-emerald-800 font-bold mb-1">سعر البيع للجمهور</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={sellPrice}
                    onChange={e => setSellPrice(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-emerald-300 font-mono font-black text-emerald-900 bg-emerald-50/50"
                  />
                </div>
                {!editingMed && (
                <div>
                  <label className="block text-slate-700 font-bold mb-1">الكمية المتوفرة</label>
                  <input
                    type="number"
                    required
                    value={stockQuantity}
                    onChange={e => setStockQuantity(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 font-mono font-bold text-slate-800"
                  />
                </div>
                )}
                <div>
                  <label className="block text-slate-700 font-bold mb-1">حد التنبيه الأدنى</label>
                  <input
                    type="number"
                    required
                    value={minQuantity}
                    onChange={e => setMinQuantity(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 font-mono text-slate-800"
                  />
                </div>
              </div>

              {!editingMed && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">تاريخ انتهاء الصلاحية *</label>
                    <input type="date" required value={expiryDate} onChange={e => setExpiryDate(e.target.value)} className="w-full p-2.5 rounded-xl border border-slate-200 font-mono text-slate-800 font-bold" />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">رقم التشغيلة / الدفعة (Batch)</label>
                    <input type="text" value={batchNumber} onChange={e => setBatchNumber(e.target.value)} className="w-full p-2.5 rounded-xl border border-slate-200 font-mono text-slate-800" />
                  </div>
                </div>
              )}

              {editingMed && (
                <div className="p-4 rounded-2xl border border-indigo-200 bg-indigo-50/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="font-black text-indigo-950">التشغيلات (كل دفعة بتاريخ انتهاء وتكلفة)</div>
                    <button
                      type="button"
                      onClick={() => setEditBatches([...editBatches, { id: uid('bat'), batchNumber: '', expiryDate: '', quantity: '0', purchasePrice: purchasePrice || '0' }])}
                      className="px-3 py-1 rounded-lg bg-indigo-700 text-white font-black"
                    >
                      + تشغيلة
                    </button>
                  </div>
                  <p className="text-slate-700">يُباع الأقدم انتهاءً أولاً تلقائياً. تعديل الكمية هنا يُسجَّل في حركة المخزون.</p>
                  <div className="space-y-2">
                    {editBatches.map((b, i) => (
                      <div key={b.id} className="grid grid-cols-12 gap-2 items-end">
                        <div className="col-span-3">
                          <label className="block text-slate-700 font-bold mb-0.5">رقم التشغيلة</label>
                          <input value={b.batchNumber} onChange={e => setEditBatches(editBatches.map((x, j) => (j === i ? { ...x, batchNumber: e.target.value } : x)))} className="w-full p-2 rounded-lg border border-slate-300 font-mono" />
                        </div>
                        <div className="col-span-3">
                          <label className="block text-slate-700 font-bold mb-0.5">الانتهاء</label>
                          <input type="date" value={b.expiryDate} onChange={e => setEditBatches(editBatches.map((x, j) => (j === i ? { ...x, expiryDate: e.target.value } : x)))} className="w-full p-2 rounded-lg border border-slate-300 font-mono" />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-slate-700 font-bold mb-0.5">الكمية</label>
                          <input type="number" min={0} value={b.quantity} onChange={e => setEditBatches(editBatches.map((x, j) => (j === i ? { ...x, quantity: e.target.value } : x)))} className="w-full p-2 rounded-lg border border-slate-300 font-mono font-bold" />
                        </div>
                        <div className="col-span-3">
                          <label className="block text-slate-700 font-bold mb-0.5">تكلفة العبوة</label>
                          <input type="number" min={0} step="0.01" value={b.purchasePrice} onChange={e => setEditBatches(editBatches.map((x, j) => (j === i ? { ...x, purchasePrice: e.target.value } : x)))} className="w-full p-2 rounded-lg border border-slate-300 font-mono" />
                        </div>
                        <button
                          type="button"
                          aria-label="حذف التشغيلة"
                          onClick={() => setEditBatches(editBatches.filter((_, j) => j !== i))}
                          className="col-span-1 p-2 rounded-lg text-rose-800 hover:bg-rose-100 font-black"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-1">
                  <label className="block text-slate-700 font-bold mb-1">الشركة المصنعة / المورد</label>
                  <input type="text" placeholder="بيرزيت، دار الشفاء، GSK..." value={manufacturer} onChange={e => setManufacturer(e.target.value)} className="w-full p-2.5 rounded-xl border border-slate-200 text-slate-800" />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">الشكل الصيدلاني</label>
                  <input type="text" placeholder="أقراص، شراب، حقن..." value={dosageForm} onChange={e => setDosageForm(e.target.value)} className="w-full p-2.5 rounded-xl border border-slate-200 text-slate-800" />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">التركيز</label>
                  <input type="text" placeholder="500mg" value={strength} onChange={e => setStrength(e.target.value)} className="w-full p-2.5 rounded-xl border border-slate-200 text-slate-800 font-mono" dir="ltr" />
                </div>
              </div>

              <div className="flex flex-wrap gap-4 p-3 rounded-2xl bg-violet-50/60 border border-violet-200">
                <label className="flex items-center gap-2 font-black text-violet-950 cursor-pointer">
                  <input type="checkbox" checked={requiresPrescription} onChange={e => setRequiresPrescription(e.target.checked)} className="w-4 h-4" />
                  يُصرف بوصفة طبية
                </label>
                <label className="flex items-center gap-2 font-black text-rose-950 cursor-pointer">
                  <input type="checkbox" checked={isControlled} onChange={e => setIsControlled(e.target.checked)} className="w-4 h-4" />
                  دواء خاضع للرقابة (يتطلب رقم الوصفة)
                </label>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">وحدات في العبوة</label>
                  <input type="number" min={1} value={unitsPerPack} onChange={e => setUnitsPerPack(e.target.value)} className="w-full p-2.5 rounded-xl border border-slate-200 font-mono font-bold" title="1 = لا يُباع بالتجزئة" />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">اسم الوحدة الصغرى</label>
                  <input type="text" placeholder="شريط / حبة" disabled={(parseInt(unitsPerPack) || 1) <= 1} value={subUnitName} onChange={e => setSubUnitName(e.target.value)} className="w-full p-2.5 rounded-xl border border-slate-200 disabled:bg-slate-100" />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">سعر الوحدة الصغرى</label>
                  <input type="number" step="0.01" min={0} placeholder="تلقائي" disabled={(parseInt(unitsPerPack) || 1) <= 1} value={subUnitPrice} onChange={e => setSubUnitPrice(e.target.value)} className="w-full p-2.5 rounded-xl border border-slate-200 font-mono disabled:bg-slate-100" />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">أدنى سعر بيع للعبوة</label>
                  <input type="number" step="0.01" min={0} placeholder="اختياري" value={minSellPrice} onChange={e => setMinSellPrice(e.target.value)} className="w-full p-2.5 rounded-xl border border-slate-200 font-mono" />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-black shadow-md shadow-cyan-600/20"
                >
                  {editingMed ? 'حفظ التعديلات' : 'إضافة الصنف'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Excel Import Modal */}
      {movementsFor && <MovementsModal medicine={movementsFor} movements={movements} onClose={() => setMovementsFor(null)} />}
      {showStocktake && <StocktakeModal medicines={medicines} onApply={onStocktake} onClose={() => setShowStocktake(false)} />}
      {showReturns && (
        <SupplierReturnModal medicines={medicines} entities={entities} nearDays={nearDays} currency={settings.currency} onSubmit={onRemoveStock} onClose={() => setShowReturns(false)} />
      )}
      {showReorder && <ReorderModal medicines={medicines} sales={sales} currency={settings.currency} onClose={() => setShowReorder(false)} />}

      {showExcelModal && (
        <Suspense fallback={null}>
      <ExcelImportModal
        isOpen={showExcelModal}
        onClose={() => setShowExcelModal(false)}
        existingMedicines={medicines}
        settings={settings}
        onImportSuccess={handleImportSuccess}
      />
        </Suspense>
      )}
    </div>
  );
};
